//! The parts of the screen a phone or tablet covers with its own controls: the status bar, the
//! navigation bar or gesture handle, a camera cutout and the on-screen keyboard.
//!
//! The platform shell reports them as `RawInput::safe_area_insets` (Android: `apps/gridcraft-android`).
//! egui's `content_rect` is the viewport without them; the window is laid out inside it, so no
//! control sits under the system's. The covered strips are painted in the colour of the chrome
//! next to them, so the system bars, which are transparent edge to edge, read as part of the
//! title bar above and the status bar (or the sheet tabs) below. On desktop and in a browser the
//! insets are zero and nothing here changes the layout.

use egui::{Color32, Rect, pos2};

use crate::SheetApp;
use crate::theme::Tokens;

/// The colours behind the system bars: what the top strip continues (the title bar and ribbon)
/// and what the bottom strip continues (the status bar, the sheet tabs or the File view).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct SystemBarColors {
    pub top: Color32,
    pub bottom: Color32,
}

impl SystemBarColors {
    /// Whether the top bar's background is light, so the system should draw dark icons on it.
    pub fn top_is_light(&self) -> bool {
        is_light(self.top)
    }

    /// Whether the bottom bar's background is light, so the system should draw dark icons on it.
    pub fn bottom_is_light(&self) -> bool {
        is_light(self.bottom)
    }
}

/// A background is light when dark icons contrast with it more than white ones do.
fn is_light(c: Color32) -> bool {
    crate::theme::contrast(c, Color32::BLACK) > crate::theme::contrast(c, Color32::WHITE)
}

impl SheetApp {
    /// The colours the system bars should continue this frame, from the active theme.
    pub fn system_bar_colors(&self, ctx: &egui::Context) -> SystemBarColors {
        let t = Tokens::get(ctx);
        let bottom = if self.backstage.is_some() {
            t.ribbon
        } else if self.ui.status_bar {
            t.status_bar
        } else {
            t.tab_bar
        };
        SystemBarColors { top: t.window, bottom }
    }
}

/// The strips of `viewport` outside `content`: top, bottom, left and right. Empty ones are left
/// out. Left and right run between the top and bottom strips, so no pixel is painted twice.
pub(crate) fn covered_strips(viewport: Rect, content: Rect) -> Vec<(Edge, Rect)> {
    let content = content.intersect(viewport);
    let strips = [
        (Edge::Top, Rect::from_min_max(viewport.min, pos2(viewport.max.x, content.min.y))),
        (Edge::Bottom, Rect::from_min_max(pos2(viewport.min.x, content.max.y), viewport.max)),
        (Edge::Left, Rect::from_min_max(pos2(viewport.min.x, content.min.y), pos2(content.min.x, content.max.y))),
        (Edge::Right, Rect::from_min_max(pos2(content.max.x, content.min.y), pos2(viewport.max.x, content.max.y))),
    ];
    strips.into_iter().filter(|(_, r)| r.width() > 0.0 && r.height() > 0.0).collect()
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Edge {
    Top,
    Bottom,
    Left,
    Right,
}

/// Paints the covered strips under everything else this frame. Returns the content rect when it
/// is smaller than the viewport, so the caller lays the window out inside it.
pub(crate) fn paint(app: &SheetApp, ctx: &egui::Context) -> Option<Rect> {
    let (viewport, content) = ctx.input(|i| (i.viewport_rect(), i.content_rect()));
    let strips = covered_strips(viewport, content);
    if strips.is_empty() {
        return None;
    }
    let colors = app.system_bar_colors(ctx);
    let painter = ctx.layer_painter(egui::LayerId::background());
    for (edge, rect) in strips {
        // The sides beside a landscape cutout continue the window colour, like the top.
        let fill = if edge == Edge::Bottom { colors.bottom } else { colors.top };
        painter.rect_filled(rect, 0.0, fill);
    }
    Some(content.intersect(viewport))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn strips_cover_exactly_what_the_content_leaves_out() {
        let viewport = Rect::from_min_max(pos2(0.0, 0.0), pos2(400.0, 800.0));
        let content = Rect::from_min_max(pos2(10.0, 24.0), pos2(390.0, 752.0));
        let strips = covered_strips(viewport, content);
        let covered: f32 = strips.iter().map(|(_, r)| r.area()).sum();
        assert!((covered + content.area() - viewport.area()).abs() < 0.01, "strips and content should tile the viewport");
        for (_, r) in &strips {
            assert!(!r.intersects(content.shrink(0.01)), "{r:?} overlaps the content");
        }
    }

    #[test]
    fn no_insets_no_strips() {
        let viewport = Rect::from_min_max(pos2(0.0, 0.0), pos2(400.0, 800.0));
        assert!(covered_strips(viewport, viewport).is_empty());
    }

    #[test]
    fn icons_contrast_with_the_bar_behind_them() {
        let light = SystemBarColors { top: Color32::from_rgb(0xF3, 0xF3, 0xF3), bottom: Color32::from_rgb(0x29, 0x29, 0x29) };
        assert!(light.top_is_light());
        assert!(!light.bottom_is_light());
    }
}
