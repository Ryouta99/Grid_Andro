#!/usr/bin/env bash
# Build the Android app:  $DIST/gridcraft-android-<version>-<debug|release>.apk
#
# Usage: packaging/android/package.sh [--debug] [--abi <android abi>]... [--skip-build]
#
# Needs: the Android SDK (ANDROID_HOME, platform 36 and build tools) and NDK (ANDROID_NDK_HOME,
# r28 or newer, which links 16 KB-page libraries), a JDK 17+, Gradle 8.13+ (or a wrapper made with
# `gradle wrapper` in this directory), cargo-ndk (cargo install cargo-ndk) and the Rust targets:
#   rustup target add aarch64-linux-android x86_64-linux-android
# A release APK is signed when GRIDCRAFT_ANDROID_KEYSTORE is set (see docs/android.md); otherwise
# Gradle leaves it unsigned.
set -euo pipefail
# shellcheck source=../env.sh
. "$(dirname "${BASH_SOURCE[0]}")/../env.sh"
HERE="$ROOT/packaging/android"

PROFILE=release
BUILD=1
ABIS=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --debug) PROFILE=debug ;;
    --skip-build) BUILD=0 ;;
    --abi) shift; ABIS+=("${1:?--abi needs a value}") ;;
    *) echo "error: unknown option $1" >&2; exit 2 ;;
  esac
  shift
done
[[ ${#ABIS[@]} -gt 0 ]] || ABIS=(arm64-v8a x86_64)

if [[ $BUILD -eq 1 ]]; then
  command -v cargo-ndk >/dev/null || { echo "error: cargo-ndk not found (cargo install cargo-ndk)" >&2; exit 1; }
  [[ -n "${ANDROID_NDK_HOME:-}" || -n "${ANDROID_HOME:-}" ]] || { echo "error: set ANDROID_NDK_HOME (or ANDROID_HOME with an ndk/ folder)" >&2; exit 1; }
  ndk_args=()
  for abi in "${ABIS[@]}"; do ndk_args+=(-t "$abi"); done
  cargo_args=(build -p gridcraft-android)
  [[ $PROFILE == release ]] && cargo_args+=(--release)
  rm -rf "$HERE/app/src/main/jniLibs"
  # -P 26: the app's minSdk. 16 KB pages: what Android 15+ devices and Google Play require.
  RUSTFLAGS="${RUSTFLAGS:-} -C link-arg=-Wl,-z,max-page-size=16384" \
    cargo ndk "${ndk_args[@]}" -P 26 -o "$HERE/app/src/main/jniLibs" "${cargo_args[@]}"
fi

for abi in "${ABIS[@]}"; do
  [[ -f "$HERE/app/src/main/jniLibs/$abi/libgridcraft_android.so" ]] || { echo "error: no libgridcraft_android.so for $abi; run without --skip-build" >&2; exit 1; }
done

GRADLE="$HERE/gradlew"
[[ -x "$GRADLE" ]] || GRADLE="$(command -v gradle || true)"
[[ -n "$GRADLE" ]] || { echo "error: neither ./gradlew nor gradle found" >&2; exit 1; }
TASK=assembleRelease
[[ $PROFILE == debug ]] && TASK=assembleDebug
(cd "$HERE" && GRIDCRAFT_VERSION="$VERSION" "$GRADLE" --no-daemon "$TASK")

OUT="$HERE/app/build/outputs/apk/$PROFILE"
APK="$(find "$OUT" -maxdepth 1 -name '*.apk' | head -n 1)"
[[ -n "$APK" ]] || { echo "error: Gradle produced no APK in $OUT" >&2; exit 1; }
mkdir -p "$DIST"
cp "$APK" "$DIST/gridcraft-android-$VERSION-$PROFILE.apk"
echo "$DIST/gridcraft-android-$VERSION-$PROFILE.apk"
