// GridCraft for Android: the APK around libgridcraft_android.so. Build with ./package.sh, which
// compiles the Rust library with cargo-ndk into app/src/main/jniLibs first.
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "gridcraft-android"
include(":app")
