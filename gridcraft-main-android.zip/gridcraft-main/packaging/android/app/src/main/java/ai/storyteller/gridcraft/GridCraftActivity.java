// GridCraft on Android: the activity around the Rust app (apps/gridcraft-android).
//
// NativeActivity runs `android_main` from libgridcraft_android.so. This subclass adds what the
// Rust side can't do from its own thread:
//
// - Edge to edge: the window draws under transparent system bars (required when targeting
//   Android 15), and the insets of the status bar, navigation bar, display cutout and keyboard are
//   recorded for `safeInsets()`. GridCraft lays itself out inside them and paints the covered
//   strips in its title bar and status bar colours.
// - `setSystemBarStyle`: dark or light status bar and navigation bar icons, so they stay legible
//   on GridCraft's light and dark themes.
// - The system document screens for Open, Insert > Pictures and Save As / Export, the clipboard,
//   the print service and links. Results are queued for `takeDelivered()`.
//
// Every public method is called from the Rust app thread over JNI; anything that touches views
// or starts an activity is posted to the UI thread.
package ai.storyteller.gridcraft;

import android.app.NativeActivity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.DisplayCutout;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.window.OnBackInvokedDispatcher;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayDeque;

public final class GridCraftActivity extends NativeActivity {
    private static final String TAG = "GridCraft";
    private static final int REQUEST_OPEN = 1;
    private static final int REQUEST_PICTURE = 2;
    private static final int REQUEST_SAVE = 3;
    /** Larger files are refused rather than read into memory whole. */
    private static final long MAX_FILE_BYTES = 512L * 1024 * 1024;

    private static final String XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    private static final String[] WORKBOOK_TYPES = {
        XLSX,
        "application/vnd.ms-excel.sheet.macroEnabled.12",
        "application/vnd.ms-excel.sheet.binary.macroEnabled.12",
        "application/vnd.ms-excel",
        "application/vnd.oasis.opendocument.spreadsheet",
        "text/csv",
        "text/comma-separated-values",
        "text/tab-separated-values",
        "text/plain",
        "application/json",
        // Some storage providers don't know the spreadsheet types and report this instead.
        "application/octet-stream",
    };

    private final Object lock = new Object();
    /** left, top, right, bottom in physical pixels; guarded by `lock`. */
    private final int[] insets = new int[4];
    /** {kind, name, bytes} records for `takeDelivered`; guarded by `lock`. */
    private final ArrayDeque<Object[]> delivered = new ArrayDeque<>();
    /** What Save As will write once the user picks a place; guarded by `lock`. */
    private byte[] pendingSave;
    private String pendingSaveName;
    private volatile boolean nightMode;
    private ClipboardManager clipboard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        layOutEdgeToEdge(window);
        nightMode = isNight(getResources().getConfiguration());
        clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        View decor = window.getDecorView();
        decor.setOnApplyWindowInsetsListener((view, windowInsets) -> {
            recordInsets(windowInsets);
            return view.onApplyWindowInsets(windowInsets);
        });
        decor.requestApplyInsets();
        // Back leaves GridCraft running in the background instead of closing it with the open
        // workbooks; Android's own predictive back (Android 13+) does the same.
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, () -> moveTaskToBack(true));
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        nightMode = isNight(newConfig);
        getWindow().getDecorView().requestApplyInsets();
    }

    private static boolean isNight(Configuration config) {
        return (config.uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    /** Transparent status and navigation bars over a window that fills the screen. */
    @SuppressWarnings("deprecation")
    private static void layOutEdgeToEdge(Window window) {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
        } else {
            window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            // No grey scrim behind three-button navigation: GridCraft paints that strip itself.
            window.setStatusBarContrastEnforced(false);
            window.setNavigationBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(attributes);
        }
    }

    /** The system bars, the cutout and (at the bottom) the keyboard, whichever is larger. */
    @SuppressWarnings("deprecation")
    private void recordInsets(WindowInsets windowInsets) {
        int left, top, right, bottom;
        if (Build.VERSION.SDK_INT >= 30) {
            android.graphics.Insets bars = windowInsets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            android.graphics.Insets ime = windowInsets.getInsets(WindowInsets.Type.ime());
            left = bars.left;
            top = bars.top;
            right = bars.right;
            bottom = Math.max(bars.bottom, ime.bottom);
        } else {
            left = windowInsets.getSystemWindowInsetLeft();
            top = windowInsets.getSystemWindowInsetTop();
            right = windowInsets.getSystemWindowInsetRight();
            bottom = windowInsets.getSystemWindowInsetBottom();
            if (Build.VERSION.SDK_INT >= 28) {
                DisplayCutout cutout = windowInsets.getDisplayCutout();
                if (cutout != null) {
                    left = Math.max(left, cutout.getSafeInsetLeft());
                    top = Math.max(top, cutout.getSafeInsetTop());
                    right = Math.max(right, cutout.getSafeInsetRight());
                    bottom = Math.max(bottom, cutout.getSafeInsetBottom());
                }
            }
        }
        synchronized (lock) {
            insets[0] = left;
            insets[1] = top;
            insets[2] = right;
            insets[3] = bottom;
        }
    }

    // ---- Called from Rust -------------------------------------------------------------------

    /** left, top, right, bottom: what the system covers, in physical pixels. */
    public int[] safeInsets() {
        synchronized (lock) {
            return insets.clone();
        }
    }

    public boolean isNightMode() {
        return nightMode;
    }

    /**
     * `lightStatusBar`: the strip behind the status bar is light, so the clock and icons are drawn
     * dark. The same for the navigation bar.
     */
    @SuppressWarnings("deprecation")
    public void setSystemBarStyle(final boolean lightStatusBar, final boolean lightNavigationBar) {
        runOnUiThread(() -> {
            Window window = getWindow();
            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsetsController controller = window.getInsetsController();
                if (controller == null) {
                    return;
                }
                int appearance = (lightStatusBar ? WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS : 0)
                    | (lightNavigationBar ? WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS : 0);
                controller.setSystemBarsAppearance(appearance,
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            } else {
                View decor = window.getDecorView();
                int flags = decor.getSystemUiVisibility();
                flags = lightStatusBar ? flags | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : flags & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (Build.VERSION.SDK_INT >= 26) {
                    flags = lightNavigationBar ? flags | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : flags & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                }
                decor.setSystemUiVisibility(flags);
            }
        });
    }

    public void openDocument() {
        runOnUiThread(() -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, WORKBOOK_TYPES);
            start(intent, REQUEST_OPEN);
        });
    }

    public void pickPicture() {
        runOnUiThread(() -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/png", "image/jpeg"});
            start(intent, REQUEST_PICTURE);
        });
    }

    public void saveDocument(final String name, final byte[] bytes) {
        synchronized (lock) {
            pendingSave = bytes;
            pendingSaveName = name;
        }
        runOnUiThread(() -> {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mimeFor(name));
            intent.putExtra(Intent.EXTRA_TITLE, name);
            start(intent, REQUEST_SAVE);
        });
    }

    public void printPdf(final String job, final byte[] pdf) {
        runOnUiThread(() -> {
            PrintManager printing = (PrintManager) getSystemService(PRINT_SERVICE);
            if (printing == null) {
                deliver("failed", "Printing is not available on this device.", null);
                return;
            }
            printing.print(job, new PdfDocumentAdapter(job, pdf), new PrintAttributes.Builder().build());
        });
    }

    public void openUrl(final String url) {
        runOnUiThread(() -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (ActivityNotFoundException e) {
                deliver("failed", "No app on this device opens " + url, null);
            }
        });
    }

    public boolean setClipboard(String text, String html) {
        if (clipboard == null) {
            return false;
        }
        try {
            clipboard.setPrimaryClip(ClipData.newHtmlText("GridCraft", text, html));
            return true;
        } catch (RuntimeException e) {
            Log.w(TAG, "clipboard copy failed", e);
            return false;
        }
    }

    public String clipboardText() {
        ClipData.Item item = clipItem();
        if (item == null) {
            return null;
        }
        CharSequence text = item.coerceToText(this);
        return text == null ? null : text.toString();
    }

    public String clipboardHtml() {
        ClipData.Item item = clipItem();
        return item == null ? null : item.getHtmlText();
    }

    /** The oldest delivery as {kind, name, bytes}, or null. Kinds: open, picture, saved, cancelled, failed. */
    public Object[] takeDelivered() {
        synchronized (lock) {
            return delivered.poll();
        }
    }

    // ---- Results ----------------------------------------------------------------------------

    private ClipData.Item clipItem() {
        if (clipboard == null) {
            return null;
        }
        try {
            ClipData clip = clipboard.getPrimaryClip();
            return clip == null || clip.getItemCount() == 0 ? null : clip.getItemAt(0);
        } catch (RuntimeException e) {
            Log.w(TAG, "clipboard read failed", e);
            return null;
        }
    }

    @SuppressWarnings("deprecation")
    private void start(Intent intent, int request) {
        try {
            startActivityForResult(intent, request);
        } catch (ActivityNotFoundException e) {
            if (request == REQUEST_SAVE) {
                clearPendingSave();
            }
            deliver("failed", "This device has no app for choosing files.", null);
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        final Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
        if (uri == null) {
            if (request == REQUEST_SAVE) {
                clearPendingSave();
            }
            deliver("cancelled", "", null);
            return;
        }
        // Reading and writing go to a worker: a large workbook would stall the UI thread.
        new Thread(() -> {
            switch (request) {
                case REQUEST_OPEN: read(uri, "open"); break;
                case REQUEST_PICTURE: read(uri, "picture"); break;
                case REQUEST_SAVE: write(uri); break;
                default: break;
            }
        }, "GridCraft files").start();
    }

    private void read(Uri uri, String kind) {
        String name = displayName(uri);
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) {
                throw new IOException("the file could not be opened");
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[64 * 1024];
            long total = 0;
            for (int n; (n = in.read(buffer)) > 0; ) {
                total += n;
                if (total > MAX_FILE_BYTES) {
                    throw new IOException("the file is larger than 512 MB");
                }
                out.write(buffer, 0, n);
            }
            deliver(kind, name, out.toByteArray());
        } catch (IOException | RuntimeException e) {
            deliver("failed", "Couldn't read " + name + ": " + e.getMessage(), null);
        }
    }

    private void write(Uri uri) {
        byte[] bytes;
        String name;
        synchronized (lock) {
            bytes = pendingSave;
            name = pendingSaveName;
            pendingSave = null;
            pendingSaveName = null;
        }
        if (bytes == null) {
            return;
        }
        String shown = displayName(uri);
        // "wt": replace what an existing document held instead of overwriting only its start.
        try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) {
                throw new IOException("the place could not be written");
            }
            out.write(bytes);
            deliver("saved", shown != null ? shown : name, null);
        } catch (IOException | RuntimeException e) {
            deliver("failed", "Couldn't save " + name + ": " + e.getMessage(), null);
        }
    }

    private void clearPendingSave() {
        synchronized (lock) {
            pendingSave = null;
            pendingSaveName = null;
        }
    }

    private void deliver(String kind, String name, byte[] bytes) {
        synchronized (lock) {
            delivered.add(new Object[] {kind, name, bytes});
        }
    }

    /**
     * The document's file name. GridCraft reads the format from its extension, so one is added from
     * the type when the provider gives a bare name.
     */
    private String displayName(Uri uri) {
        String name = null;
        try (Cursor cursor = getContentResolver().query(uri, new String[] {OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                name = cursor.getString(0);
            }
        } catch (RuntimeException e) {
            Log.w(TAG, "no display name for " + uri, e);
        }
        if (name == null || name.isEmpty()) {
            String last = uri.getLastPathSegment();
            name = last != null && !last.isEmpty() ? last : "Book1";
        }
        if (name.lastIndexOf('.') <= 0) {
            String extension = extensionFor(getContentResolver().getType(uri));
            if (extension != null) {
                name = name + "." + extension;
            }
        }
        return name;
    }

    private static String extensionFor(String mime) {
        if (mime == null) {
            return null;
        }
        switch (mime) {
            case XLSX: return "xlsx";
            case "application/vnd.ms-excel.sheet.macroEnabled.12": return "xlsm";
            case "application/vnd.ms-excel.sheet.binary.macroEnabled.12": return "xlsb";
            case "application/vnd.ms-excel": return "xls";
            case "application/vnd.oasis.opendocument.spreadsheet": return "ods";
            case "text/csv":
            case "text/comma-separated-values": return "csv";
            case "text/tab-separated-values": return "tsv";
            case "text/plain": return "txt";
            case "application/json": return "json";
            case "image/png": return "png";
            case "image/jpeg": return "jpg";
            default: return null;
        }
    }

    private static String mimeFor(String name) {
        String lower = name.toLowerCase(java.util.Locale.ROOT);
        if (lower.endsWith(".xlsx")) return XLSX;
        if (lower.endsWith(".pdf")) return "application/pdf";
        if (lower.endsWith(".csv")) return "text/csv";
        if (lower.endsWith(".html") || lower.endsWith(".htm")) return "text/html";
        if (lower.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    /** Hands an already finished PDF to the print service. */
    private static final class PdfDocumentAdapter extends PrintDocumentAdapter {
        private final String name;
        private final byte[] pdf;

        PdfDocumentAdapter(String name, byte[] pdf) {
            this.name = name.toLowerCase(java.util.Locale.ROOT).endsWith(".pdf") ? name : name + ".pdf";
            this.pdf = pdf;
        }

        @Override
        public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes, CancellationSignal cancel,
                             LayoutResultCallback callback, Bundle extras) {
            if (cancel.isCanceled()) {
                callback.onLayoutCancelled();
                return;
            }
            PrintDocumentInfo info = new PrintDocumentInfo.Builder(name)
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .build();
            callback.onLayoutFinished(info, !newAttributes.equals(oldAttributes));
        }

        @Override
        public void onWrite(PageRange[] pages, ParcelFileDescriptor destination, CancellationSignal cancel, WriteResultCallback callback) {
            if (cancel.isCanceled()) {
                callback.onWriteCancelled();
                return;
            }
            try (FileOutputStream out = new FileOutputStream(destination.getFileDescriptor())) {
                out.write(pdf);
                callback.onWriteFinished(new PageRange[] {PageRange.ALL_PAGES});
            } catch (IOException e) {
                callback.onWriteFailed(e.getMessage());
            }
        }
    }
}
