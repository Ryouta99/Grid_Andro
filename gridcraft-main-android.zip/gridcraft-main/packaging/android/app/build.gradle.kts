// The Java side is one class (GridCraftActivity) on the platform SDK alone: no AndroidX, no
// Kotlin, no other dependency.
plugins {
    id("com.android.application")
}

// The version follows the Cargo workspace (`GRIDCRAFT_VERSION`, set by package.sh).
val gridcraftVersion: String = providers.environmentVariable("GRIDCRAFT_VERSION").getOrElse("0.0.0")
val versionParts = gridcraftVersion.split('.', '-').mapNotNull { it.toIntOrNull() } + listOf(0, 0, 0)

android {
    namespace = "ai.storyteller.gridcraft"
    compileSdk = 36

    defaultConfig {
        applicationId = "ai.storyteller.gridcraft"
        // Android 8.0: AAudio-free, Vulkan or GLES 3 for wgpu, and the window inset APIs used
        // by GridCraftActivity (with fallbacks below Android 11).
        minSdk = 26
        // Android 15 and later draw every app edge to edge; GridCraft lays itself out in the
        // safe area instead of opting out.
        targetSdk = 36
        versionCode = versionParts[0] * 10000 + versionParts[1] * 100 + versionParts[2]
        versionName = gridcraftVersion
        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Sign with your own key: set GRIDCRAFT_ANDROID_KEYSTORE and friends (docs/android.md).
            val keystore = providers.environmentVariable("GRIDCRAFT_ANDROID_KEYSTORE").orNull
            if (keystore != null) {
                signingConfig = signingConfigs.create("gridcraft") {
                    storeFile = file(keystore)
                    storePassword = providers.environmentVariable("GRIDCRAFT_ANDROID_KEYSTORE_PASSWORD").orNull
                    keyAlias = providers.environmentVariable("GRIDCRAFT_ANDROID_KEY_ALIAS").orNull
                    keyPassword = providers.environmentVariable("GRIDCRAFT_ANDROID_KEY_PASSWORD").orNull
                }
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        jniLibs {
            // Stored uncompressed and page-aligned, so Android maps the library in place.
            useLegacyPackaging = false
        }
    }
}
